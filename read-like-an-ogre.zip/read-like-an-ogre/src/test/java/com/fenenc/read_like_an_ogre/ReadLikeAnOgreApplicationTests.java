package com.fenenc.read_like_an_ogre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadLikeAnOgreApplicationTests {

	@Test
	void contextLoads() {
	}

}
